/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { JobAlert, NewsNotification } from './types';

export const INITIAL_JOB_ALERTS: JobAlert[] = [
  {
    id: 'cg-job-001',
    title: 'CGPSC Civil Services (SSE) Examination 2026',
    department: 'CGPSC',
    shortDesc: 'Chhattisgarh Public Service Commission announcement for State Service Exam to recruit Deputy Collectors, DSPs, Naib Tehsildars, and Account Officers.',
    vacancies: 242,
    qualification: ['Graduate'],
    startDate: '2026-06-15',
    lastDate: '2026-07-20',
    examDate: '2026-09-14 (Prelims)',
    feeDetails: {
      general: '₹400 / Out-Of-State Candidates',
      obc: '₹0 (CG Native Residents)',
      sc_st: '₹0 (CG Native Residents)',
      pwd: '₹0 (CG Native Residents)',
      remarks: 'Application correction fee of ₹508 applies for changes. CG residents do not pay registration fees.'
    },
    ageLimit: '21 to 30 Years (Up to 40 Years for Chhattisgarh Local Candidates)',
    applyUrl: 'https://psc.cg.gov.in',
    pdfUrl: 'https://psc.cg.gov.in/pdf/Recruitment/ADV_SSE_2026.pdf',
    syllabus: [
      'Prelims Paper I: General Studies (100 MCQ, 200 Marks) covering Chhattisgarh History, Culture, Geography, Indian Polity, Science & Tech.',
      'Prelims Paper II: General Aptitude & Logical Reasoning (100 MCQ, 200 Marks - Qualifying class of 33%).',
      'Mains Exam: 7 papers (Written-descriptive style) of 200 marks each, followed by a personality test (Interview - 100 Marks).'
    ],
    examStructure: 'Written Exam (Prelims + Mains) followed by Personal Interview',
    districts: 'All Districts of Chhattisgarh (Exam centers in standard district headquarters)',
    selectionProcess: [
      'Preliminary Screening Test (Objective)',
      'Main Written Examination (Descriptive)',
      'Personal Interview / Document Verification'
    ],
    isFeatured: true,
    isActive: true
  },
  {
    id: 'cg-job-002',
    title: 'CG Vyapam Hostel Superintendent (Grade-D) Recruitment 2026',
    department: 'CG Vyapam',
    shortDesc: 'Chhattisgarh Professional Examination Board invites online applications for Hostel Superintendents (Hostel Warden Grade-D) under Tribal and Scheduled Caste Development Department.',
    vacancies: 300,
    qualification: ['12th Pass', 'ITI/Diploma'],
    startDate: '2026-06-01',
    lastDate: '2026-06-30',
    examDate: '2026-08-10',
    feeDetails: {
      general: '₹0 (CG Residents)',
      obc: '₹0 (CG Residents)',
      sc_st: '₹0 (CG Residents)',
      pwd: '₹0 (CG Residents)',
      remarks: 'Free of registration cost for all domicile candidates of CG under state policy. Out-of-state fees: ₹350.'
    },
    ageLimit: '21 to 35 Years (Standard concessions of 5-10 years for reserved classes & female applicants)',
    applyUrl: 'https://vyapam.cgstate.gov.in',
    pdfUrl: 'https://vyapam.cgstate.gov.in/pdf/Recruitment/Hostel_Warden_2026.pdf',
    syllabus: [
      'Computer Knowledge (50 Questions, 50 Marks - Compulsory to score minimum 25 marks in computer section!).',
      'Hindi Grammar & English Vocabulary (20 Marks total).',
      'Mathematics (25 Marks) covering interest, ratio, geometry, and basic arithmetic.',
      'General Knowledge, CG General Information, and Current Affairs (25 Marks).'
    ],
    examStructure: 'Single-tier OMR based competitive exam (Negative marking system of 1/4th)',
    districts: 'Exam conducted at 32 District Headquarters in CG',
    selectionProcess: [
      'Written MCQ Optical Mark Recognition (OMR) Exam',
      'Merit List and District Wise Counselling',
      'Physical and Mental Fitness Check & Document Verification'
    ],
    isFeatured: true,
    isActive: true
  },
  {
    id: 'cg-job-003',
    title: 'CG Police Constable (Constable - GD, Driver & Trades) Recruits',
    department: 'CG Police',
    shortDesc: 'Chhattisgarh Police Recruitment Cell is hiring massive constable roles across multiple districts including Raipur, Durg, Bastar, Bilaspur, and Surguja ranges.',
    vacancies: 5967,
    qualification: ['8th/10th Pass'],
    startDate: '2026-05-15',
    lastDate: '2026-07-15',
    examDate: 'Physical test in August 2026; Written exam in September 2026',
    feeDetails: {
      general: '₹200',
      obc: '₹200',
      sc_st: '₹125',
      pwd: '₹125',
      remarks: 'Fees payable through Online net-banking, UPI or Credit/Debit card options directly in CG Police Bharti Portal.'
    },
    ageLimit: '18 to 28 Years (Relaxed up to 5 additional years for SC/ST and OBC candidates of Chhattisgarh)',
    applyUrl: 'https://cgpolice.gov.in',
    pdfUrl: 'https://cgpolice.gov.in/recruitment/Constable_Rules_2026.pdf',
    syllabus: [
      'Physical Standards: Height 168cm (Male), 158cm (Female). Chest expansion 81-86cm for general males.',
      'Physical Efficiency Test (PET): 100m, 800m run, Long jump, High jump, and Shot put elements.',
      'Written Competitive Exam (100 Marks): General Knowledge, Intellect Ability, Analytical Ability & Arithmetic (2-hour duration).'
    ],
    examStructure: 'Physical Measurement Test (PMT) -> Physical Efficiency Test (PET) -> Written MCQ Exam -> Medical test',
    districts: 'Raipur, Bilaspur, Bastar, Durg, Jagdalpur, Surguja and other specialized CG Police battalions',
    selectionProcess: [
      'Physical Measurement and Security Eligibility',
      'Physical Efficiency Test (PET) - 100 marks standard scoring',
      'Written Test (100 marks)',
      'Bonus details (National certificate, sports certificate - max 10 marks)'
    ],
    isFeatured: true,
    isActive: true
  },
  {
    id: 'cg-job-004',
    title: 'CG Education Department Teacher & Lecturer Recruitment 2026',
    department: 'Education Dept',
    shortDesc: 'Directorate of Public Instruction (DPI) Chhattisgarh announces teaching staff requirements for Mathematics, English, Physics, and Commerce lecturers in Swami Atmanand Schools & State Schools.',
    vacancies: 1240,
    qualification: ['Graduate', 'Post Graduate', 'B.Ed/D.El.Ed'],
    startDate: '2026-06-20',
    lastDate: '2026-07-25',
    examDate: '2026-09-05',
    feeDetails: {
      general: '₹0 (CG Residents)',
      obc: '₹0 (CG Residents)',
      sc_st: '₹0 (CG Residents)',
      pwd: '₹0 (CG Residents)',
      remarks: 'Zero fee policy active for CG native applicants. Non-CG applicants have to pay standard testing fee of ₹400.'
    },
    ageLimit: '21 to 40 Years (Age relaxation up to 45 years for female and reserved category aspirants of CG)',
    applyUrl: 'https://eduportal.cg.nic.in',
    pdfUrl: 'https://eduportal.cg.nic.in/recruitment/ADVT_LECTURER_2026.pdf',
    syllabus: [
      'Subject Specific Syllabus (Post Graduate standard for Lecturers, Graduate standard for Teachers) - 100 Marks.',
      'Child Development and Pedagogy (30 Marks covering behavioral, learning and special education concepts).',
      'General Hindi, General English and Computer Basics (20 Marks total).'
    ],
    examStructure: 'Written OMR-based Exam of 150 Marks with subsequent Document Verification',
    districts: 'All divisions of Chhattisgarh (Raipur, Bilaspur, Bastar, Durg, Surguja)',
    selectionProcess: [
      'Written Competitive Exam (150 Objective items)',
      'CG-Teacher Eligibility Test (CG-TET) Certificate Verification (Required only for Primary teaching roles)',
      'Document and Work Internship Checks'
    ],
    isFeatured: false,
    isActive: true
  },
  {
    id: 'cg-job-005',
    title: 'CG Forest Guard (Forest Guard) & Driver Positions 2026',
    department: 'Forest Dept',
    shortDesc: 'Office of Principal Chief Conservator of Forest, Raipur invites young applicants for recruitment of Forest Guards and Forest Rangers with attractive scale grades.',
    vacancies: 1484,
    qualification: ['12th Pass'],
    startDate: '2026-07-01',
    lastDate: '2026-08-05',
    examDate: '2026-10-12',
    feeDetails: {
      general: '₹350',
      obc: '₹250',
      sc_st: '₹200',
      pwd: '₹0 (Exempt)',
      remarks: 'Eligible candidates can make card payment via direct integration link on CG Forest Board login page.'
    },
    ageLimit: '18 to 40 Years (Max 5-year extension for SC/ST and OBC CG native certificate holders)',
    applyUrl: 'https://cgforest.com',
    pdfUrl: 'https://cgforest.com/bharti_forest_guard_2026.pdf',
    syllabus: [
      'Physical Standards: Male height (ST: 152cm, Others: 163cm); Female height (ST: 145cm, Others: 150cm).',
      'Walking Test: Male candidates must walk 25 km in 4 hours; female candidates must walk 14 km in 4 hours.',
      'Written test details: Science, Environmental Studies, Mathematics, General Knowledge of CG and India.'
    ],
    examStructure: 'Physical Measurement -> Walking Efficiency -> Written Test (100 Marks) -> Medical assessment',
    districts: 'Bastar, Jagdalpur, Kabirdham, Bilaspur, Raipur, Raigarh forest circles',
    selectionProcess: [
      'Height and Chest Measurement Criteria Check',
      'Endurance Physical Evaluation (Walking/Efficiency)',
      'Written Competitive Evaluation',
      'Merit allocation on visual parameters'
    ],
    isFeatured: false,
    isActive: true
  },
  {
    id: 'cg-job-006',
    title: 'CG High Court Bilaspur Assistant Grade-III Recruitment 2026',
    department: 'High Court',
    shortDesc: 'High Court of Chhattisgarh, Bilaspur releases jobs for Assistant Grade-III (AG-III) and English Stenographer roles with computer skills requirement.',
    vacancies: 114,
    qualification: ['Graduate'],
    startDate: '2026-05-20',
    lastDate: '2026-06-25',
    examDate: '2026-07-28',
    feeDetails: {
      general: '₹0 (CG Residents & Reserved)',
      obc: '₹0 (Others also exempt)',
      sc_st: '₹0',
      pwd: '₹0',
      remarks: 'No application fees charged by High Court Bilaspur under transparency recruit directives. Out of state candidates also get exemption.'
    },
    ageLimit: '21 to 30 Years (Up to 40 Years for CG Native Domicile)',
    applyUrl: 'https://highcourt.cg.gov.in',
    pdfUrl: 'https://highcourt.cg.gov.in/recruitment/AG3_ADVT_2026.pdf',
    syllabus: [
      'Written Prelims Test: English Language Grammar, Logical Aptitude, General Computer Applications.',
      'Practical Skill Test: English shorthand dictation typing at Speed of 100 w.p.m, Hindi typing test (250 words inside Linux Ubuntu OS with LibreOffice writer with Krutidev / Unicode font layout).'
    ],
    examStructure: 'Phase I (Written Screening) followed by Phase II (Strict Ubuntu Computer Speed Typing/Stenography Test)',
    districts: 'Bilaspur High Court premises',
    selectionProcess: [
      'Screening Evaluation Test',
      'Strict Computer Typing & Practical MS/Libre-Office Skills Trial (50 Marks)',
      'Final Board Document Assessment'
    ],
    isFeatured: false,
    isActive: true
  }
];

export const INITIAL_NEWS: NewsNotification[] = [
  {
    id: 'news-001',
    title: '🔥 Hot Recruitment: CGPSC SSE Prelims 2026 Examination date announced. Scheduled for Sept 14, 2026.',
    date: '2026-06-12',
    category: 'notification',
    urgency: 'high',
    link: 'https://psc.cg.gov.in'
  },
  {
    id: 'news-002',
    title: '📢 CG Vyapam Hostel Warden online applications are now live! Last date to apply is June 30.',
    date: '2026-06-01',
    category: 'new-job',
    urgency: 'high',
    link: 'https://vyapam.cgstate.gov.in'
  },
  {
    id: 'news-003',
    title: '✅ CG Vyapam PPT (Pre-Polytechnic Test) 2026 Merit List & Results Declared. Check direct download links here.',
    date: '2026-06-10',
    category: 'result',
    urgency: 'normal',
    link: 'https://vyapam.cgstate.gov.in'
  },
  {
    id: 'news-004',
    title: '🎫 Admit card download portal link active for High Court Bilaspur Assistant Grade-III Exam.',
    date: '2026-06-08',
    category: 'admit-card',
    urgency: 'high',
    link: 'https://highcourt.cg.gov.in'
  },
  {
    id: 'news-005',
    title: '📝 Model Answer Key released for CG Forest Guard Physical criteria trials held in Bilaspur range.',
    date: '2026-05-28',
    category: 'answer-key',
    urgency: 'low',
    link: 'https://cgforest.com'
  }
];

export const CHHATTISGARH_DISTRICTS = [
  'All Chhattisgarh', 'Raipur', 'Bilaspur', 'Durg', 'Bhilai', 'Rajnandgaon', 'Korba', 'Raigarh', 
  'Jagdalpur (Bastar)', 'Ambikapur (Surguja)', 'Dhamtari', 'Mahasamund', 'Janjgir-Champa', 
  'Kanker', 'Kabirdham (Kawardha)', 'Balod', 'Bemetara', 'Baloda Bazar', 'Gariaband', 
  'Kondagaon', 'Narayanpur', 'Bijapur', 'Dantewada', 'Sukma', 'Mungeli', 'Surajpur', 
  'Balrampur', 'Gaurela-Pendra-Marwahi', 'Sarangarh-Bilaigarh', 'Khairagarh-Chhuikhadan-Gandai', 
  'Manendragarh-Chirmiri-Bharatpur', 'Shakti'
];
