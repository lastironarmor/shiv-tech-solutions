/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export interface FeeDetails {
  general: string;
  obc: string;
  sc_st: string;
  pwd: string;
  remarks?: string;
}

export interface JobAlert {
  id: string;
  title: string;
  department: string;
  shortDesc: string;
  vacancies: number;
  qualification: string[];
  startDate: string;
  lastDate: string;
  examDate: string;
  feeDetails: FeeDetails;
  ageLimit: string;
  applyUrl: string;
  pdfUrl: string;
  syllabus: string[];
  examStructure: string;
  districts: string;
  selectionProcess: string[];
  isFeatured?: boolean;
  contactEmail?: string;
  contactPhone?: string;
  isActive?: boolean;
}

export interface NewsNotification {
  id: string;
  title: string;
  date: string;
  category: 'result' | 'admit-card' | 'new-job' | 'answer-key' | 'notification';
  link?: string;
  urgency: 'high' | 'normal' | 'low';
}
