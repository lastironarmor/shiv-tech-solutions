/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useMemo, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  Search,
  Building,
  GraduationCap,
  Calendar,
  MapPin,
  Clock,
  Sparkles,
  Lock,
  Unlock,
  Bookmark,
  FileText,
  Share2,
  Plus,
  Trash2,
  Edit,
  RotateCcw,
  Printer,
  Check,
  ExternalLink,
  ChevronRight,
  Copy,
  Info,
  X,
  PlusCircle,
  TrendingUp,
  AlertTriangle,
  BadgeAlert
} from 'lucide-react';
import { JobAlert, NewsNotification, FeeDetails } from './types';
import { INITIAL_JOB_ALERTS, INITIAL_NEWS, CHHATTISGARH_DISTRICTS } from './data';

export default function App() {
  // State variables
  const [jobs, setJobs] = useState<JobAlert[]>([]);
  const [news, setNews] = useState<NewsNotification[]>([]);
  const [selectedJob, setSelectedJob] = useState<JobAlert | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedDept, setSelectedDept] = useState<string>('All');
  const [selectedQual, setSelectedQual] = useState<string>('All');
  const [selectedStatus, setSelectedStatus] = useState<string>('All');
  const [bookmarks, setBookmarks] = useState<string[]>([]);
  const [showBookmarksOnly, setShowBookmarksOnly] = useState(false);
  
  // Admin-related state
  const [isAdmin, setIsAdmin] = useState(false);
  const [adminPassword, setAdminPassword] = useState('');
  const [showAdminLogin, setShowAdminLogin] = useState(false);
  const [showAdminForm, setShowAdminForm] = useState(false);
  const [errorMsg, setErrorMsg] = useState('');
  const [formMode, setFormMode] = useState<'create' | 'edit'>('create');
  
  // Notification ticker index
  const [tickerIndex, setTickerIndex] = useState(0);

  // Print-oriented reference
  const printRef = useRef<HTMLDivElement>(null);

  // Form State for job registration
  const [editingJobId, setEditingJobId] = useState<string | null>(null);
  const [formTitle, setFormTitle] = useState('');
  const [formDept, setFormDept] = useState('CGPSC');
  const [formShortDesc, setFormShortDesc] = useState('');
  const [formVacancies, setFormVacancies] = useState<number>(100);
  const [formQuals, setFormQuals] = useState<string[]>(['Graduate']);
  const [formStartDate, setFormStartDate] = useState('2026-06-15');
  const [formLastDate, setFormLastDate] = useState('2026-07-20');
  const [formExamDate, setFormExamDate] = useState('To be announced');
  const [formGeneralFee, setFormGeneralFee] = useState('₹400 / Out-Of-State Candidates');
  const [formObcFee, setFormObcFee] = useState('₹0 (CG Residents)');
  const [formScStFee, setFormScStFee] = useState('₹0 (CG Residents)');
  const [formPwdFee, setFormPwdFee] = useState('₹0 (CG Residents)');
  const [formFeeRemarks, setFormFeeRemarks] = useState('Fee exemption under local resident regulations applies.');
  const [formAgeLimit, setFormAgeLimit] = useState('21 to 30 Years (Up to 45 years for CG Candidates)');
  const [formApplyUrl, setFormApplyUrl] = useState('https://psc.cg.gov.in');
  const [formPdfUrl, setFormPdfUrl] = useState('https://psc.cg.gov.in');
  const [formSyllabus, setFormSyllabus] = useState<string>('General GK, Chhattisgarh Local History, Aptitude');
  const [formExamStructure, setFormExamStructure] = useState('Written MCQ + Main Descriptive');
  const [formDistricts, setFormDistricts] = useState('All Chhattisgarh');
  const [formSelection, setFormSelection] = useState<string>('Screening Test, Written Papers, Board Interview');
  const [formIsFeatured, setFormIsFeatured] = useState<boolean>(false);

  // Load Initial state from LocalStorage on mount
  useEffect(() => {
    const savedJobs = localStorage.getItem('cg_jobs_alert_v1');
    if (savedJobs) {
      const parsed = JSON.parse(savedJobs) as JobAlert[];
      setJobs(parsed);
      if (parsed.length > 0) setSelectedJob(parsed[0]);
    } else {
      localStorage.setItem('cg_jobs_alert_v1', JSON.stringify(INITIAL_JOB_ALERTS));
      setJobs(INITIAL_JOB_ALERTS);
      setSelectedJob(INITIAL_JOB_ALERTS[0]);
    }

    const savedNews = localStorage.getItem('cg_news_v1');
    if (savedNews) {
      setNews(JSON.parse(savedNews));
    } else {
      localStorage.setItem('cg_news_v1', JSON.stringify(INITIAL_NEWS));
      setNews(INITIAL_NEWS);
    }

    const savedBookmarks = localStorage.getItem('cg_bookmarks_v1');
    if (savedBookmarks) {
      setBookmarks(JSON.parse(savedBookmarks));
    }

    const savedAdmin = sessionStorage.getItem('cg_admin_v1');
    if (savedAdmin === 'true') {
      setIsAdmin(true);
    }
  }, []);

  // Update localStorage when state changes
  const saveJobsToStorage = (updatedJobs: JobAlert[]) => {
    localStorage.setItem('cg_jobs_alert_v1', JSON.stringify(updatedJobs));
    setJobs(updatedJobs);
  };

  // Auto-rotating News ticker
  useEffect(() => {
    if (news.length === 0) return;
    const interval = setInterval(() => {
      setTickerIndex((prev) => (prev + 1) % news.length);
    }, 4500);
    return () => clearInterval(interval);
  }, [news]);

  // Handle Bookmarks Toggle
  const toggleBookmark = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    let updatedBookmarks: string[];
    if (bookmarks.includes(id)) {
      updatedBookmarks = bookmarks.filter((bId) => bId !== id);
    } else {
      updatedBookmarks = [...bookmarks, id];
    }
    setBookmarks(updatedBookmarks);
    localStorage.setItem('cg_bookmarks_v1', JSON.stringify(updatedBookmarks));
  };

  // Handle Admin Authorization
  const handleAdminLogin = (e: React.FormEvent) => {
    e.preventDefault();
    if (adminPassword === '12345') {
      setIsAdmin(true);
      sessionStorage.setItem('cg_admin_v1', 'true');
      setShowAdminLogin(false);
      setAdminPassword('');
      setErrorMsg('');
    } else {
      setErrorMsg('Incorrect admin password. Please try again.');
    }
  };

  // Handle Admin Logout
  const handleAdminLogout = () => {
    setIsAdmin(false);
    sessionStorage.removeItem('cg_admin_v1');
    setShowAdminForm(false);
  };

  // Reset to original Seed Data handler
  const resetToSeedData = () => {
    if (window.confirm('Are you sure you want to reset all portal data to initial defaults? All custom notifications will be lost.')) {
      localStorage.setItem('cg_jobs_alert_v1', JSON.stringify(INITIAL_JOB_ALERTS));
      localStorage.setItem('cg_news_v1', JSON.stringify(INITIAL_NEWS));
      setJobs(INITIAL_JOB_ALERTS);
      setSelectedJob(INITIAL_JOB_ALERTS[0]);
      setNews(INITIAL_NEWS);
      alert('Chhattisgarh Job Alerts Portal data reset successfully.');
    }
  };

  // Open Form to Create Job Alert
  const openCreateForm = () => {
    setFormMode('create');
    setEditingJobId(null);
    setFormTitle('');
    setFormDept('CGPSC');
    setFormShortDesc('');
    setFormVacancies(120);
    setFormQuals(['Graduate']);
    setFormStartDate(new Date().toISOString().split('T')[0]);
    // Set last date as 30 days after
    const futureDate = new Date();
    futureDate.setDate(futureDate.getDate() + 30);
    setFormLastDate(futureDate.toISOString().split('T')[0]);
    setFormExamDate('To be announced');
    setFormGeneralFee('₹400 / Out-Of-State Candidates');
    setFormObcFee('₹0 (CG Residents)');
    setFormScStFee('₹0 (CG Residents)');
    setFormPwdFee('₹0 (CG Residents)');
    setFormFeeRemarks('Free of charge for all candidates holding Chhattisgarh domicile.');
    setFormAgeLimit('21 to 30 Years (Up to 40 Years for CG domicile candidates)');
    setFormApplyUrl('https://psc.cg.gov.in');
    setFormPdfUrl('https://psc.cg.gov.in');
    setFormSyllabus('Paper I: General Knowledge, Paper II: Aptitude');
    setFormExamStructure('Written Competitive MCQ + Documentation check');
    setFormDistricts('All Chhattisgarh');
    setFormSelection('Written Test, Interview / Skill Evaluation');
    setFormIsFeatured(false);
    setShowAdminForm(true);
  };

  // Edit Job Alert Mode
  const openEditForm = (job: JobAlert, e: React.MouseEvent) => {
    e.stopPropagation();
    setFormMode('edit');
    setEditingJobId(job.id);
    setFormTitle(job.title);
    setFormDept(job.department);
    setFormShortDesc(job.shortDesc);
    setFormVacancies(job.vacancies);
    setFormQuals(job.qualification);
    setFormStartDate(job.startDate);
    setFormLastDate(job.lastDate);
    setFormExamDate(job.examDate);
    setFormGeneralFee(job.feeDetails.general);
    setFormObcFee(job.feeDetails.obc);
    setFormScStFee(job.feeDetails.sc_st);
    setFormPwdFee(job.feeDetails.pwd);
    setFormFeeRemarks(job.feeDetails.remarks || '');
    setFormAgeLimit(job.ageLimit);
    setFormApplyUrl(job.applyUrl);
    setFormPdfUrl(job.pdfUrl);
    setFormSyllabus(job.syllabus.join('\n'));
    setFormExamStructure(job.examStructure);
    setFormDistricts(job.districts);
    setFormSelection(job.selectionProcess.join(', '));
    setFormIsFeatured(!!job.isFeatured);
    setShowAdminForm(true);
  };

  // Submit Job Alert Form
  const handleFormSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    if (!formTitle.trim() || !formShortDesc.trim() || !formApplyUrl.trim()) {
      alert('Please fill out all required fields: Title, Description, and Application Link.');
      return;
    }

    const cleanSyllabus = formSyllabus.split('\n').filter(line => line.trim() !== '');
    const cleanSelection = formSelection.split(',').map(item => item.trim()).filter(item => item !== '');

    const newJob: JobAlert = {
      id: formMode === 'create' ? `cg-job-${Date.now()}` : (editingJobId || `cg-job-${Date.now()}`),
      title: formTitle,
      department: formDept,
      shortDesc: formShortDesc,
      vacancies: Number(formVacancies) || 0,
      qualification: formQuals,
      startDate: formStartDate,
      lastDate: formLastDate,
      examDate: formExamDate,
      feeDetails: {
        general: formGeneralFee,
        obc: formObcFee,
        sc_st: formScStFee,
        pwd: formPwdFee,
        remarks: formFeeRemarks
      },
      ageLimit: formAgeLimit,
      applyUrl: formApplyUrl,
      pdfUrl: formPdfUrl,
      syllabus: cleanSyllabus.length > 0 ? cleanSyllabus : ['Syllabus and guidelines to be released in statutory notification.'],
      examStructure: formExamStructure,
      districts: formDistricts,
      selectionProcess: cleanSelection.length > 0 ? cleanSelection : ['Competitive Examination', 'Assessment'],
      isFeatured: formIsFeatured,
      isActive: true
    };

    let updatedList: JobAlert[] = [];
    if (formMode === 'create') {
      updatedList = [newJob, ...jobs];
      // Create a matching Live Alert News item automatically!
      const newNewsItem: NewsNotification = {
        id: `news-${Date.now()}`,
        title: `🔥 New Recruitment: ${newJob.title} - ${newJob.vacancies} vacancies invited.`,
        date: new Date().toISOString().split('T')[0],
        category: 'new-job',
        urgency: 'high',
        link: newJob.applyUrl
      };
      const updatedNewsList = [newNewsItem, ...news];
      setNews(updatedNewsList);
      localStorage.setItem('cg_news_v1', JSON.stringify(updatedNewsList));
    } else {
      updatedList = jobs.map(j => j.id === editingJobId ? newJob : j);
    }

    saveJobsToStorage(updatedList);
    setSelectedJob(newJob);
    setShowAdminForm(false);
    alert(formMode === 'create' ? 'Recruitment advertisement published successfully!' : 'Recruitment advertisement updated successfully!');
  };

  // Delete Job Alert
  const handleJobDelete = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    if (window.confirm('Are you sure you want to permanently delete this recruitment advertisement?')) {
      const updatedList = jobs.filter(j => j.id !== id);
      saveJobsToStorage(updatedList);
      if (selectedJob && selectedJob.id === id) {
        setSelectedJob(updatedList.length > 0 ? updatedList[0] : null);
      }
      alert('Recruitment advertisement successfully deleted.');
    }
  };

  // Toggle qualification in checklist form
  const handleQualsCheck = (qual: string) => {
    if (formQuals.includes(qual)) {
      if (formQuals.length > 1) {
        setFormQuals(formQuals.filter(q => q !== qual));
      }
    } else {
      setFormQuals([...formQuals, qual]);
    }
  };

  // Quick preset loader helper for admin
  const applyAdminPreset = (presetType: 'PSC' | 'Vyapam' | 'Police') => {
    if (presetType === 'PSC') {
      setFormDept('CGPSC');
      setFormApplyUrl('https://psc.cg.gov.in');
      setFormPdfUrl('https://psc.cg.gov.in');
      setFormGeneralFee('₹400 / Out-Of-State Candidates');
      setFormObcFee('₹0 (CG Residents)');
      setFormScStFee('₹0 (CG Residents)');
      setFormAgeLimit('21 to 30 Years (Up to 40 Years for CG candidates)');
      setFormExamStructure('Prelims MCQ (2 papers) -> Written Mains (7 Papers) -> Board Interview');
    } else if (presetType === 'Vyapam') {
      setFormDept('CG Vyapam');
      setFormApplyUrl('https://vyapam.cgstate.gov.in');
      setFormPdfUrl('https://vyapam.cgstate.gov.in');
      setFormGeneralFee('₹0 (Exempt under State Policy)');
      setFormObcFee('₹0 (CG Residents)');
      setFormScStFee('₹0 (CG Residents)');
      setFormAgeLimit('18 to 35 Years (Standard relaxation of 5-10 years applies)');
      setFormExamStructure('Single Session Objective OMR Evaluation with Negative Marks of 1/4th');
    } else if (presetType === 'Police') {
      setFormDept('CG Police');
      setFormApplyUrl('https://cgpolice.gov.in');
      setFormPdfUrl('https://cgpolice.gov.in');
      setFormGeneralFee('₹200');
      setFormObcFee('₹200');
      setFormScStFee('₹125');
      setFormAgeLimit('18 to 28 Years');
      setFormExamStructure('Physical Standard Screening -> Physical Efficiency Run -> Written Aptitude -> Medical');
    }
  };

  // Filters Calculation
  const departments = useMemo(() => {
    const list = new Set(jobs.map(j => j.department));
    return ['All', ...Array.from(list)];
  }, [jobs]);

  const qualifications = ['All', '8th/10th Pass', '12th Pass', 'Graduate', 'Post Graduate', 'ITI/Diploma'];

  // Filter & Search Engine
  const filteredJobs = useMemo(() => {
    return jobs.filter((job) => {
      // 1. Text Search Query matching title, department, qualification, or description
      const text = `${job.title} ${job.department} ${job.shortDesc} ${job.qualification.join(' ')}`.toLowerCase();
      const matchesSearch = text.includes(searchQuery.toLowerCase());

      // 2. Department filter selection
      const matchesDept = selectedDept === 'All' || job.department === selectedDept;

      // 3. Qualification level match
      const matchesQual = selectedQual === 'All' || job.qualification.some(q => {
        if (selectedQual === '8th/10th Pass') return q.includes('8th') || q.includes('10th');
        return q === selectedQual;
      });

      // 4. Time status check
      const today = new Date().toISOString().split('T')[0];
      const jobLastDate = job.lastDate;
      const isDateOver = today > jobLastDate;
      
      let matchesStatus = true;
      if (selectedStatus === 'Active') {
        matchesStatus = !isDateOver;
      } else if (selectedStatus === 'Closing Soon') {
        if (isDateOver) {
          matchesStatus = false;
        } else {
          const tDate = new Date();
          const lDate = new Date(jobLastDate);
          const diffTime = Math.abs(lDate.getTime() - tDate.getTime());
          const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
          matchesStatus = diffDays <= 7;
        }
      } else if (selectedStatus === 'Closed') {
        matchesStatus = isDateOver;
      }

      // 5. Bookmark Filter Toggle
      const matchesBookmarks = !showBookmarksOnly || bookmarks.includes(job.id);

      return matchesSearch && matchesDept && matchesQual && matchesStatus && matchesBookmarks;
    });
  }, [jobs, searchQuery, selectedDept, selectedQual, selectedStatus, showBookmarksOnly, bookmarks]);

  // Set default selected job when list shifts
  useEffect(() => {
    if (filteredJobs.length > 0) {
      // Keep existing selection if it resides in the current filtered set OR set to first item
      const exists = filteredJobs.some(j => selectedJob && j.id === selectedJob.id);
      if (!exists) setSelectedJob(filteredJobs[0]);
    } else {
      setSelectedJob(null);
    }
  }, [filteredJobs]);

  // Calculate stats summary count variables
  const statsSummary = useMemo(() => {
    const today = new Date().toISOString().split('T')[0];
    const live = jobs.filter(j => today <= j.lastDate).length;
    const totalOpenings = jobs.reduce((sum, j) => sum + (today <= j.lastDate ? j.vacancies : 0), 0);
    
    // Urgent vacancies (ending in under 7 days)
    const closingSoon = jobs.filter(j => {
      if (today > j.lastDate) return false;
      const tDate = new Date();
      const lDate = new Date(j.lastDate);
      const diffTime = Math.abs(lDate.getTime() - tDate.getTime());
      const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
      return diffDays <= 7;
    }).length;

    return { live, totalOpenings, closingSoon };
  }, [jobs]);

  // WhatsApp Group message compiler
  const compileWhatsAppShare = (job: JobAlert) => {
    const text = `🔥 *CHHATTISGARH GOVT JOB ALERT* 🔥\n\n🏢 *Department:* ${job.department}\n🎯 *Title:* ${job.title}\n💼 *Total Vacancies:* ${job.vacancies} Posts\n🎓 *Qualification:* ${job.qualification.join(' / ')}\n📅 *Start Date:* ${formatReadableDate(job.startDate)}\n📅 *End Date:* ${formatReadableDate(job.lastDate)}\n\n🔴 *Exam Date:* ${job.examDate}\n✅ *Age Limit:* ${job.ageLimit}\n\n📢 *Download Official Notification PDF:* \n🔗 ${job.pdfUrl}\n\n👉 *Direct Online Application Link:* \n🔗 ${job.applyUrl}\n\n👥 *Share with your friends and groups!*`;
    navigator.clipboard.writeText(text);
    alert('WhatsApp share message format copied successfully! You can now paste it directly into any WhatsApp group or chat.');
  };

  // Helper date conversions
  function formatReadableDate(dateStr: string) {
    if (!dateStr) return '';
    try {
      const parts = dateStr.split('-');
      if (parts.length === 3) {
        return `${parts[2]}/${parts[1]}/${parts[0]}`;
      }
      return dateStr;
    } catch {
      return dateStr;
    }
  }

  // Get active countdown
  const getDaysLeft = (lastDateStr: string) => {
    const today = new Date().setHours(0,0,0,0);
    const deadline = new Date(lastDateStr).setHours(0,0,0,0);
    const diffTime = deadline - today;
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    return diffDays;
  };

  // Print function
  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col antialiased">
      {/* Tricolor Top Decor Header Rule Bar */}
      <div className="h-2 w-full grid grid-cols-3">
        <div className="bg-[#FF9933]"></div> {/* Saffron */}
        <div className="bg-white"></div>     {/* White */}
        <div className="bg-[#138808]"></div> {/* India Green */}
      </div>

      {/* Main Header */}
      <header className="bg-slate-900 border-b border-slate-800 text-white shadow-md sticky top-0 z-40">
        <div className="max-w-7xl mx-auto px-4 py-3 sm:px-6 lg:px-8 flex flex-col md:flex-row md:items-center md:justify-between gap-4">
          
          {/* Logo Brand Accent Title */}
          <div className="flex items-center space-x-3">
            <div className="bg-[#FF9933]/15 text-[#FF9933] p-2 rounded-xl border border-[#FF9933]/30 flex items-center justify-center">
              <Building className="h-6 w-6" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-[10px] bg-red-600/95 tracking-widest text-white px-2 py-0.5 rounded font-bold uppercase font-mono animate-pulse">Official Info</span>
                <span className="text-xs text-orange-400 font-medium font-sans">Govt of Chhattisgarh</span>
              </div>
              <h1 className="text-lg md:text-xl font-bold tracking-tight text-white flex items-center gap-1.5">
                C.G. GOVT JOB PORTAL <span className="text-orange-500 font-semibold font-mono">2026</span>
              </h1>
              <p className="text-[11px] text-slate-400 font-medium tracking-wide font-sans">
                Chhattisgarh Government Regular & Contractual Recruitment Hub
              </p>
            </div>
          </div>

          {/* Search, Bookmarks and Admin Switch controls */}
          <div className="flex flex-wrap items-center gap-2 md:gap-3">
            {/* Quick Bookmark Filter Active/Inactive Toggle */}
            <button
              onClick={() => setShowBookmarksOnly(!showBookmarksOnly)}
              className={`flex items-center space-x-1 px-3.5 py-1.5 rounded-lg text-xs font-semibold tracking-wide border transition-all ${
                showBookmarksOnly
                  ? 'bg-amber-500 border-amber-500 text-slate-950 font-bold shadow-sm'
                  : 'bg-slate-800 hover:bg-slate-755 text-amber-400 border-slate-750'
              }`}
            >
              <Bookmark className={`h-3.5 w-3.5 ${showBookmarksOnly ? 'fill-slate-950 text-slate-950' : 'fill-amber-400'}`} />
              <span>Bookmarks ({bookmarks.length})</span>
            </button>

            {/* Admin trigger */}
            {isAdmin ? (
              <div className="flex items-center gap-2 bg-emerald-950 border border-emerald-500/30 px-3 py-1 rounded-lg text-emerald-400 text-xs font-semibold shadow-inner">
                <Unlock className="h-3.5 w-3.5 text-emerald-400" />
                <span>Admin Active</span>
                <button
                  onClick={handleAdminLogout}
                  className="ml-2 hover:bg-red-500 hover:text-white bg-slate-800 text-slate-300 px-2 py-0.5 rounded transition text-[10px]"
                >
                  Logout
                </button>
              </div>
            ) : (
              <button
                onClick={() => setShowAdminLogin(true)}
                className="flex items-center space-x-1.5 px-3 py-1.5 bg-slate-800 hover:bg-slate-705 text-slate-200 border border-slate-700 hover:border-slate-650 rounded-lg text-xs font-medium transition cursor-pointer"
              >
                <Lock className="h-3.5 w-3.5 text-orange-400" />
                <span>Officer Login</span>
              </button>
            )}

            {isAdmin && (
              <button
                onClick={resetToSeedData}
                title="Reset to default alerts dataset"
                className="p-1.5 rounded-lg border border-red-500/40 text-red-400 bg-red-950/10 hover:bg-red-950/45 transition cursor-pointer"
              >
                <RotateCcw className="h-4 w-4" />
              </button>
            )}
          </div>

        </div>
      </header>

      {/* Live Rotating News Ticker Bar */}
      {news.length > 0 && (
        <div id="cg-news-ticker" className="bg-amber-50 border-b border-amber-200/90 text-amber-950 py-2.5 px-4">
          <div className="max-w-7xl mx-auto flex items-center space-x-3 overflow-hidden text-xs md:text-sm">
            <span className="flex-shrink-0 bg-amber-600 text-white font-bold px-2 py-0.5 rounded-md text-[10px] tracking-wider uppercase animate-pulse flex items-center gap-1">
              <BadgeAlert className="h-3 w-3" /> BREAKING NEWS
            </span>
            <div className="flex-1 truncate font-medium">
              <AnimatePresence mode="wait">
                <motion.div
                  key={tickerIndex}
                  initial={{ opacity: 0, y: 12 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -12 }}
                  transition={{ duration: 0.3 }}
                  className="flex items-center gap-1.5 cursor-pointer hover:underline"
                >
                  <span className="text-[10px] text-amber-700 bg-amber-100 font-bold px-1.5 py-0.2 rounded font-mono">
                    {formatReadableDate(news[tickerIndex].date)}
                  </span>
                  <a href={news[tickerIndex].link} target="_blank" rel="noopener noreferrer" className="truncate">
                    {news[tickerIndex].title}
                  </a>
                </motion.div>
              </AnimatePresence>
            </div>
            <div className="flex items-center gap-1 text-[11px] text-amber-705 hidden md:flex font-sans">
              <span>{tickerIndex + 1} / {news.length}</span>
              <button
                onClick={() => setTickerIndex((tickerIndex + 1) % news.length)}
                className="p-0.5 hover:bg-amber-150 rounded"
              >
                <ChevronRight className="h-4 w-4" />
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Main Core Dashboard & Container View Body */}
      <main className="flex-grow max-w-7xl w-full mx-auto px-4 py-4 sm:px-6 lg:px-8 flex flex-col gap-5">
        
        {/* Metric High-contrast Summary Board */}
        <section className="grid grid-cols-1 md:grid-cols-3 gap-3.5 mt-1">
          
          {/* Box 1: Live alerts count */}
          <div className="bg-white border border-slate-200 shadow-sm hover:shadow transition-shadow rounded-xl p-3.5 flex items-center space-x-3.5">
            <div className="p-2.5 rounded-lg bg-emerald-50 text-emerald-600">
              <TrendingUp className="h-6 w-6" />
            </div>
            <div>
              <p className="text-xs font-semibold text-slate-500 uppercase tracking-widest font-sans">Active Job Alerts</p>
              <div className="flex items-baseline space-x-2">
                <h3 className="text-2xl font-bold text-slate-800 font-mono">{statsSummary.live}</h3>
                <span className="text-[10.5px] text-emerald-600 bg-emerald-50 py-0.5 px-2 rounded-full font-semibold font-sans">
                  🔴 Live Now
                </span>
              </div>
            </div>
          </div>

          {/* Box 2: Total open posts */}
          <div className="bg-white border border-slate-200 shadow-sm hover:shadow transition-shadow rounded-xl p-3.5 flex items-center space-x-3.5">
            <div className="p-2.5 rounded-lg bg-indigo-50 text-indigo-600">
              <GraduationCap className="h-6 w-6" />
            </div>
            <div>
              <p className="text-xs font-semibold text-slate-500 uppercase tracking-widest font-sans">Total Live Openings</p>
              <div className="flex items-baseline space-x-2">
                <h3 className="text-2xl font-bold text-slate-800 font-mono">
                  {statsSummary.totalOpenings.toLocaleString('en-IN')}
                </h3>
                <span className="text-[10.5px] text-indigo-600 bg-indigo-55/10 py-0.5 px-2 rounded font-medium font-sans">
                  State Domicile Vacancies
                </span>
              </div>
            </div>
          </div>

          {/* Box 3: Urgent Dates approaching */}
          <div className="bg-white border border-slate-200 shadow-sm hover:shadow transition-shadow rounded-xl p-3.5 flex items-center space-x-3.5">
            <div className={`p-2.5 rounded-lg ${statsSummary.closingSoon > 0 ? 'bg-amber-50 text-amber-600' : 'bg-slate-100 text-slate-500'}`}>
              <Clock className="h-6 w-6 animate-pulse" />
            </div>
            <div>
              <p className="text-xs font-semibold text-slate-500 uppercase tracking-widest font-sans">Deadlines Looming</p>
              <div className="flex items-baseline space-x-2">
                <h3 className="text-2xl font-bold text-slate-800 font-mono">{statsSummary.closingSoon}</h3>
                {statsSummary.closingSoon > 0 ? (
                  <span className="text-[10.5px] text-red-600 bg-red-50 py-0.5 px-2 rounded-full font-bold animate-pulse font-sans">
                    ⏰ Closing in 7 Days
                  </span>
                ) : (
                  <span className="text-[10.5px] text-slate-505 bg-slate-100 py-0.5 px-2 rounded-full font-medium font-sans">
                    No urgent deadlines
                  </span>
                )}
              </div>
            </div>
          </div>

        </section>

        {/* Global Advance Filtering Row */}
        <section className="bg-white border border-slate-200 rounded-xl p-4 shadow-sm flex flex-col gap-4">
          <div className="flex flex-col md:flex-row gap-3">
            {/* Search filter wrapper */}
            <div className="relative flex-grow">
              <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                <Search className="h-4.5 w-4.5 text-slate-400" />
              </div>
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search by agency name, post title or qualification... (e.g., Hostels, Vyapam, Clerk, Police)"
                className="block w-full pl-10 pr-4 py-2.5 border border-slate-200 rounded-lg text-slate-800 text-sm focus:outline-none focus:ring-2 focus:ring-orange-400 focus:border-orange-400 bg-slate-50 transition-all font-medium placeholder:text-slate-400"
              />
              {searchQuery && (
                <button
                  onClick={() => setSearchQuery('')}
                  className="absolute inset-y-0 right-0 pr-3 flex items-center text-slate-400 hover:text-slate-600"
                >
                  <X className="h-4 w-4" />
                </button>
              )}
            </div>

            {/* Quick Status Filter Select */}
            <div className="flex items-center space-x-2 min-w-[200px]">
              <span className="text-xs font-bold text-slate-550 uppercase whitespace-nowrap">Status:</span>
              <select
                value={selectedStatus}
                onChange={(e) => setSelectedStatus(e.target.value)}
                className="block w-full py-2 px-3 border border-slate-200 rounded-lg text-xs bg-slate-50 text-slate-700 font-bold focus:ring-1 focus:ring-orange-400 text-center"
              >
                <option value="All">All statuses (All Channels)</option>
                <option value="Active">Apply Online Active</option>
                <option value="Closing Soon">Ending Soon (Under 7 Days)</option>
                <option value="Closed">Expired Notifications</option>
              </select>
            </div>
          </div>

          {/* Expanded selection filter chips */}
          <div className="space-y-2.5 pt-1 border-t border-slate-100">
            {/* Dept selector row */}
            <div className="flex flex-wrap items-center gap-2">
              <span className="text-xs font-bold text-slate-500 uppercase tracking-wider min-w-[90px]">Agency (Dept):</span>
              <div className="flex flex-wrap gap-1.5">
                {departments.map((dept) => {
                  const jobCount = jobs.filter(j => dept === 'All' || j.department === dept).length;
                  return (
                    <button
                      key={dept}
                      onClick={() => setSelectedDept(dept)}
                      className={`text-xs px-2.5 py-1 rounded-md transition-all font-semibold uppercase ${
                        selectedDept === dept
                          ? 'bg-slate-900 text-white font-bold'
                          : 'bg-slate-100 hover:bg-slate-200 text-slate-700 text-[11px]'
                      }`}
                    >
                      {dept === 'All' ? 'All Departments' : dept} <span className="opacity-60 ml-0.5">({jobCount})</span>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Education selector row */}
            <div className="flex flex-wrap items-center gap-2">
              <span className="text-xs font-bold text-slate-500 uppercase tracking-wider min-w-[90px]">Education:</span>
              <div className="flex flex-wrap gap-1.5">
                {qualifications.map((qual) => {
                  return (
                    <button
                      key={qual}
                      onClick={() => setSelectedQual(qual)}
                      className={`text-xs px-2.5 py-1 rounded-md transition-all font-semibold ${
                        selectedQual === qual
                          ? 'bg-orange-500 text-white font-bold'
                          : 'bg-slate-100 hover:bg-slate-200 text-slate-600 text-[11px]'
                      }`}
                    >
                      {qual === 'All' ? 'All Qualifications' : qual}
                    </button>
                  );
                })}
              </div>
            </div>
          </div>
        </section>

        {/* Dynamic List and Detail Two Column Layout */}
        <section className="grid grid-cols-1 lg:grid-cols-12 gap-5 items-start">
          
          {/* Left Column: Cards List View of job notifications- Grid weight 5 */}
          <div className="lg:col-span-5 space-y-3.5 md:max-h-[750px] md:overflow-y-auto pr-1">
            
            <div className="flex items-center justify-between px-1">
              <h4 className="text-xs font-bold text-slate-500 uppercase tracking-widest flex items-center gap-1.5">
                📂 Job Alert Board ({filteredJobs.length} Alerts found)
              </h4>
              {isAdmin && (
                <button
                  onClick={openCreateForm}
                  className="flex items-center space-x-1 px-3 py-1 bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold rounded-lg shadow-sm transition"
                >
                  <Plus className="h-3.5 w-3.5" />
                  <span>Publish New Alert</span>
                </button>
              )}
            </div>

            {filteredJobs.length === 0 ? (
              <div className="bg-white border border-slate-200 rounded-xl p-8 text-center text-slate-500 shadow-sm">
                <AlertTriangle className="h-10 w-10 text-amber-500 mx-auto mb-2" />
                <h5 className="font-bold text-slate-700">No recruitment alerts found</h5>
                <p className="text-xs mt-1">Please modify your search query or filter settings.</p>
                {showBookmarksOnly && (
                  <button
                    onClick={() => setShowBookmarksOnly(false)}
                    className="mt-3 text-xs text-orange-600 font-bold underline"
                  >
                    Clear Bookmarks Filter
                  </button>
                )}
              </div>
            ) : (
              <div className="space-y-3">
                {filteredJobs.map((job) => {
                  const daysLeft = getDaysLeft(job.lastDate);
                  const isClosed = daysLeft < 0;
                  const isClosingSoon = !isClosed && daysLeft <= 7;
                  const isFeatured = !!job.isFeatured;
                  const isSelected = selectedJob?.id === job.id;

                  // Define unique styling/badge based on government agency
                  let deptColorClass = 'text-blue-600 bg-blue-50 border-blue-200/50';
                  if (job.department === 'CGPSC') deptColorClass = 'text-amber-700 bg-amber-50 border-amber-200/50';
                  if (job.department === 'CG Vyapam') deptColorClass = 'text-indigo-700 bg-indigo-50 border-indigo-200/50';
                  if (job.department === 'CG Police') deptColorClass = 'text-red-700 bg-red-50 border-red-200/50';
                  if (job.department === 'Forest Dept') deptColorClass = 'text-emerald-700 bg-emerald-50 border-emerald-200/50';
                  if (job.department === 'High Court') deptColorClass = 'text-sky-700 bg-sky-50 border-sky-200/50';

                  return (
                    <div
                      key={job.id}
                      onClick={() => setSelectedJob(job)}
                      className={`group relative bg-white border rounded-xl p-4 cursor-pointer transition-all shadow-sm ${
                        isSelected
                          ? 'border-orange-500 ring-2 ring-orange-100/50'
                          : 'border-slate-200 hover:border-slate-300 hover:shadow'
                      } ${isFeatured ? 'bg-orange-50/20' : ''}`}
                    >
                      {/* Left feature highlights accent ribbon */}
                      {isFeatured && (
                        <div className="absolute top-0 left-0 h-full w-1.5 bg-[#FF9933] rounded-l-xl"></div>
                      )}

                      {/* Flex Card Information Header */}
                      <div className="flex justify-between items-start gap-1">
                        <span className={`text-[10px] font-bold tracking-wide uppercase px-2 py-0.5 rounded-full border ${deptColorClass}`}>
                          {job.department}
                        </span>
                        
                        <div className="flex items-center space-x-1.5">
                          {/* Duration Badge */}
                          {isClosed ? (
                            <span className="text-[9px] bg-slate-200 text-slate-600 px-1.5 py-0.5 rounded font-bold font-mono uppercase">
                              EXPIRED
                            </span>
                          ) : isClosingSoon ? (
                            <span className="text-[9px] bg-red-100 text-red-700 px-1.5 py-0.5 rounded font-bold font-mono uppercase animate-pulse">
                              ⏳ {daysLeft} Days Left
                            </span>
                          ) : (
                            <span className="text-[9px] bg-emerald-100 text-emerald-800 px-1.5 py-0.5 rounded font-semibold font-mono">
                              ACTIVE
                            </span>
                          )}

                          {/* Bookmark trigger icon link */}
                          <button
                            onClick={(e) => toggleBookmark(job.id, e)}
                            className="p-1 hover:bg-slate-100 rounded text-slate-400 hover:text-amber-500 transition"
                          >
                            <Bookmark
                              className={`h-4 w-4 ${
                                bookmarks.includes(job.id) ? 'fill-amber-400 text-amber-500' : ''
                              }`}
                            />
                          </button>
                        </div>
                      </div>

                      {/* Main Title of post */}
                      <h3 className="text-sm font-bold text-slate-800 mt-2.5 line-clamp-2 md:leading-relaxed group-hover:text-amber-700 transition">
                        {job.title}
                      </h3>

                      {/* Vacancy and qualification subline indicators */}
                      <div className="mt-3 grid grid-cols-2 gap-2 text-xs text-slate-500 border-t border-b border-dashed border-slate-100 py-2">
                        <div className="flex items-center space-x-1">
                          <GraduationCap className="h-3.5 w-3.5 text-slate-400 flex-shrink-0" />
                          <span className="truncate font-medium">{job.qualification.join(', ')}</span>
                        </div>
                        <div className="flex items-center space-x-1">
                          <PlusCircle className="h-3.5 w-3.5 text-orange-500 flex-shrink-0" />
                          <span className="font-bold text-slate-700 font-mono">
                            {job.vacancies} <span className="text-[10px] text-slate-400 font-normal font-sans">Posts</span>
                          </span>
                        </div>
                      </div>

                      {/* Bottom row: End date progress bar elements */}
                      <div className="mt-3 flex items-center justify-between text-[11px] text-slate-400 font-medium font-sans">
                        <span className="flex items-center gap-1">
                          <Calendar className="h-3 w-3" />
                          Deadline: <strong className="text-slate-650">{formatReadableDate(job.lastDate)}</strong>
                        </span>
                        
                        {/* Interactive edit handles for admin users inside individual card list */}
                        {isAdmin && (
                          <div className="flex items-center space-x-2">
                            <button
                              onClick={(e) => openEditForm(job, e)}
                              className="p-1 hover:bg-amber-100 text-amber-700 rounded transition"
                              title="Edit vacancy alert"
                            >
                              <Edit className="h-3.5 w-3.5" />
                            </button>
                            <button
                              onClick={(e) => handleJobDelete(job.id, e)}
                              className="p-1 hover:bg-red-100 text-red-605 rounded transition"
                              title="Delete notification"
                            >
                              <Trash2 className="h-3.5 w-3.5 text-red-500" />
                            </button>
                          </div>
                        )}
                      </div>

                    </div>
                  );
                })}
              </div>
            )}

          </div>

          {/* Right Column: In-depth dynamic analytical job profile - Grid weight 7 */}
          <div className="lg:col-span-7 lg:sticky lg:top-[90px] self-start space-y-4">
            
            {/* Detailed Inspect Block Panel */}
            <AnimatePresence mode="wait">
              {selectedJob ? (
                <motion.div
                  key={selectedJob.id}
                  initial={{ opacity: 0, y: 15 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -15 }}
                  transition={{ duration: 0.2 }}
                  ref={printRef}
                  className="bg-white border border-slate-200 rounded-xl p-5 shadow-sm space-y-5 print:border-none print:shadow-none"
                >
                  
                  {/* Title and Top Header info of detailed view */}
                  <div className="border-b border-slate-100 pb-4">
                    <div className="flex flex-wrap items-center justify-between gap-2 text-xs">
                      {/* Department Logo styling badge in Detail Pane */}
                      <span className="px-3 py-1 font-bold bg-slate-900 text-white rounded font-sans uppercase tracking-[0.05em]">
                        🔔 {selectedJob.department} RECRUITMENT OFFICIAL ADVERTISEMENT
                      </span>
                      
                      <button
                        onClick={() => compileWhatsAppShare(selectedJob)}
                        className="flex items-center space-x-1.5 px-3 py-1 bg-green-600 hover:bg-green-500 text-white font-bold rounded-lg transition text-xs shadow-sm cursor-pointer"
                        title="Copy post format optimized for WhatsApp"
                      >
                        <Share2 className="h-3.5 w-3.5" />
                        <span>व्हाट्सएप ग्रुप शेयर</span>
                      </button>
                    </div>

                    <h2 className="text-base md:text-lg font-bold text-slate-800 mt-3 md:leading-relaxed">
                      {selectedJob.title}
                    </h2>
                    
                    <p className="text-xs text-slate-550 italic mt-2 flex items-center gap-1.5">
                      <Info className="h-3.5 w-3.5 text-slate-400 flex-shrink-0" />
                      {selectedJob.shortDesc}
                    </p>
                  </div>

                  {/* High contrast key recruitment stats grid */}
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                    <div className="bg-slate-50 border border-slate-150 p-3 rounded-lg text-center">
                      <span className="text-[10px] font-bold text-slate-500 uppercase block tracking-wider">कुल रिक्त पद</span>
                      <strong className="text-lg font-bold text-slate-800 font-mono mt-1 block">
                        {selectedJob.vacancies}
                      </strong>
                    </div>
                    
                    <div className="bg-slate-50 border border-slate-150 p-3 rounded-lg text-center">
                      <span className="text-[10px] font-bold text-slate-500 uppercase block tracking-wider">आवश्यक योग्यता</span>
                      <strong className="text-xs font-bold text-slate-700 mt-1.5 block leading-tight truncate px-1">
                        {selectedJob.qualification.join(' / ')}
                      </strong>
                    </div>

                    <div className="bg-slate-50 border border-slate-150 p-3 rounded-lg text-center">
                      <span className="text-[10px] font-bold text-slate-500 uppercase block tracking-wider">ऑनलाइन शुरू</span>
                      <strong className="text-xs font-mono font-bold text-slate-800 mt-1.5 block">
                        {formatReadableDate(selectedJob.startDate)}
                      </strong>
                    </div>

                    <div className="bg-orange-50 border border-orange-100 p-3 rounded-lg text-center">
                      <span className="text-[10px] font-bold text-orange-700 uppercase block tracking-wider">अंतिम तिथि</span>
                      <strong className="text-xs font-mono font-bold text-orange-800 mt-1.5 block animate-pulse">
                        {formatReadableDate(selectedJob.lastDate)}
                      </strong>
                    </div>
                  </div>

                  {/* Core Structured Recruitment Specifications (Dates, Fees, Qualification, Syllabus panels) */}
                  <div className="space-y-4">
                    
                    {/* Part A: Important Dates timeline checklist */}
                    <div className="border border-slate-205 rounded-xl p-4 bg-slate-50/50">
                      <h4 className="text-xs font-extrabold text-slate-700 uppercase tracking-wider border-b border-slate-200 pb-1.5 mb-3 flex items-center gap-1.5">
                        <Calendar className="h-4 w-4 text-orange-500" />
                        Important Dates (Scheduled Timings):
                      </h4>
                      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3.5 text-xs">
                        <div>
                          <p className="text-slate-400 font-medium font-sans">Application Begins:</p>
                          <p className="font-bold text-slate-850 mt-1 font-mono flex items-center gap-1">
                            <span className="h-1.5 w-1.5 rounded-full bg-emerald-500"></span>
                            {formatReadableDate(selectedJob.startDate)}
                          </p>
                        </div>
                        <div>
                          <p className="text-slate-400 font-medium">Application Deadline:</p>
                          <p className="font-bold text-red-600 mt-1 font-mono flex items-center gap-1 animate-pulse">
                            <span className="h-1.5 w-1.5 rounded-full bg-red-500"></span>
                            {formatReadableDate(selectedJob.lastDate)}
                          </p>
                        </div>
                        <div>
                          <p className="text-slate-400 font-medium">Tentative Exam Date:</p>
                          <p className="font-bold text-blue-800 mt-1 font-sans flex items-center gap-1">
                            <span className="h-1.5 w-1.5 rounded-full bg-blue-500"></span>
                            {selectedJob.examDate}
                          </p>
                        </div>
                      </div>
                    </div>

                    {/* Part B: Detailed Recruitment Fees Tabulated */}
                    <div className="border border-slate-200 rounded-xl p-4">
                      <h4 className="text-xs font-extrabold text-slate-700 uppercase tracking-wider border-b border-slate-200 pb-1.5 mb-2.5 flex items-center gap-1.5">
                        <TrendingUp className="h-4 w-4 text-[#FF9933]" />
                        Application Registration Fees:
                      </h4>
                      <div className="grid grid-cols-2 gap-3 text-xs">
                        <div className="bg-slate-50 p-2.5 rounded border border-slate-100">
                          <span className="text-[10px] text-slate-400 uppercase tracking-wide block">General Category:</span>
                          <span className="font-bold text-slate-800 mt-0.5 block font-mono">{selectedJob.feeDetails.general}</span>
                        </div>
                        <div className="bg-slate-50 p-2.5 rounded border border-slate-100">
                          <span className="text-[10px] text-slate-400 uppercase tracking-wide block">OBC Category:</span>
                          <span className="font-bold text-slate-850 mt-0.5 block font-mono">{selectedJob.feeDetails.obc}</span>
                        </div>
                        <div className="bg-slate-50 p-2.5 rounded border border-slate-100">
                          <span className="text-[10px] text-slate-400 uppercase tracking-wide block">SC/ST Category:</span>
                          <span className="font-bold text-slate-850 mt-0.5 block font-mono">{selectedJob.feeDetails.sc_st}</span>
                        </div>
                        <div className="bg-slate-50 p-2.5 rounded border border-slate-100">
                          <span className="text-[10px] text-slate-400 uppercase tracking-wide block">PWD Category (Differently Abled):</span>
                          <span className="font-bold text-slate-850 mt-0.5 block font-mono">{selectedJob.feeDetails.pwd}</span>
                        </div>
                      </div>
                      {selectedJob.feeDetails.remarks && (
                        <p className="text-[10px] text-amber-800 bg-amber-50 rounded p-2 border border-amber-200/50 mt-2.5 font-medium leading-relaxed italic">
                          💡 <strong>Important Note:</strong> {selectedJob.feeDetails.remarks}
                        </p>
                      )}
                    </div>

                    {/* Part C: Requirements (Age, Districts, Qualification detail) */}
                    <div className="border border-slate-200 rounded-xl p-4 bg-slate-50/10 grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div>
                        <h4 className="text-xs font-extrabold text-slate-700 uppercase tracking-wider border-b border-slate-200 pb-1.5 mb-2 flex items-center gap-1.5">
                          👤 Age Limit Criteria:
                        </h4>
                        <p className="text-xs text-slate-700 leading-relaxed font-semibold">
                          {selectedJob.ageLimit}
                        </p>
                      </div>
                      <div>
                        <h4 className="text-xs font-extrabold text-slate-700 uppercase tracking-wider border-b border-slate-200 pb-1.5 mb-2 flex items-center gap-1.5">
                          📍 Job Location / Districts:
                        </h4>
                        <p className="text-xs text-slate-700 leading-relaxed flex items-center gap-1">
                          <MapPin className="h-3.5 w-3.5 text-red-500 flex-shrink-0" />
                          <span>{selectedJob.districts}</span>
                        </p>
                      </div>
                    </div>

                    {/* Part D: Examination Syllabus Pattern */}
                    <div className="border border-slate-200 rounded-xl p-4 bg-[#FF9933]/5">
                      <h4 className="text-xs font-extrabold text-slate-700 uppercase tracking-wider border-b border-slate-150 pb-1.5 mb-3 flex items-center gap-1.5">
                        <FileText className="h-4 w-4 text-orange-500" />
                        Selection Scheme & Syllabus Pattern:
                      </h4>
                      <p className="text-xs text-slate-500 font-bold mb-2">
                        🔴 Exam Scheme: <span className="text-slate-800 ml-1 font-medium">{selectedJob.examStructure}</span>
                      </p>
                      
                      <div className="space-y-2 mt-2">
                        <p className="text-xs font-bold text-slate-700">Detailed Subject-wise Syllabus:</p>
                        <ul className="text-xs text-slate-650 space-y-1.5 pl-4 list-disc font-sans leading-relaxed">
                          {selectedJob.syllabus.map((syllLine, syllIdx) => (
                            <li key={syllIdx}>{syllLine}</li>
                          ))}
                        </ul>
                      </div>

                      {selectedJob.selectionProcess && (
                        <div className="mt-3.5 pt-3 border-t border-slate-200/60 text-xs">
                          <p className="font-bold text-slate-700 mb-2">Phases of Selection:</p>
                          <div className="flex flex-wrap gap-1.5">
                            {selectedJob.selectionProcess.map((step, stepIndex) => (
                              <span key={stepIndex} className="bg-amber-100 text-amber-900 border border-amber-200 text-xs font-semibold px-2 py-0.5 rounded text-[10.5px]">
                                {stepIndex + 1}. {step}
                              </span>
                            ))}
                          </div>
                        </div>
                      )}
                    </div>

                  </div>

                  {/* Primary Download/Apply Call-to-action Section of pane */}
                  <div className="pt-4 border-t border-slate-100 flex flex-wrap gap-3 font-sans">
                    <a
                      href={selectedJob.applyUrl}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="flex-grow flex items-center justify-center space-x-2 px-5 py-3 bg-[#FF9933] hover:bg-[#E08528] text-slate-950 font-bold text-xs uppercase tracking-wider rounded-xl transition shadow shadow-amber-500/10 cursor-pointer"
                    >
                      <span>Apply Online</span>
                      <ExternalLink className="h-4 w-4" />
                    </a>

                    <a
                      href={selectedJob.pdfUrl}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="flex items-center justify-center space-x-1.5 px-4 py-3 border border-slate-350 hover:bg-slate-100 text-slate-700 font-bold text-xs uppercase tracking-wider rounded-xl transition cursor-pointer"
                    >
                      <FileText className="h-4 w-4 text-red-500" />
                      <span>Official PDF Advertisement</span>
                    </a>

                    <button
                      onClick={handlePrint}
                      className="p-3 border border-slate-350 rounded-xl hover:bg-slate-100 text-slate-505 hover:text-slate-700 transition cursor-pointer"
                      title="Print notification flyer details"
                    >
                      <Printer className="h-4 w-4" />
                    </button>
                  </div>

                </motion.div>
              ) : (
                <div className="bg-white border border-slate-200 rounded-xl p-12 text-center text-slate-400 shadow-sm mt-8">
                  <Building className="h-12 w-12 mx-auto text-slate-200 mb-2" />
                  <p className="text-sm font-medium font-sans text-slate-500">Please select an advertisement from the left panel to examine detailed statutory info.</p>
                </div>
              )}
            </AnimatePresence>

          </div>

        </section>

      </main>

      {/* Admin Login Dialog Modal */}
      {showAdminLogin && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4 z-50">
          <motion.div
            initial={{ scale: 0.95, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            className="bg-white rounded-2xl w-full max-w-sm overflow-hidden shadow-2xl border border-slate-200"
          >
            <div className="bg-slate-900 px-5 py-3.5 text-white flex justify-between items-center font-sans">
              <h3 className="text-sm font-bold tracking-wider uppercase flex items-center gap-1.5">
                <Lock className="h-4 w-4 text-orange-400" />
                Officer Login (Admin Verification)
              </h3>
              <button
                onClick={() => { setShowAdminLogin(false); setErrorMsg(''); }}
                className="text-slate-400 hover:text-white"
              >
                <X className="h-5 w-5" />
              </button>
            </div>
            
            <form onSubmit={handleAdminLogin} className="p-5 space-y-4 font-sans">
              <p className="text-xs text-slate-500 leading-relaxed font-semibold">
                Submit your administration password below to publish, edit, or delete recruitment alerts.
              </p>
              
              <div>
                <label className="block text-[11px] font-extrabold text-slate-500 uppercase tracking-widest pl-1 mb-1">
                  Password:
                </label>
                <input
                  type="password"
                  value={adminPassword}
                  onChange={(e) => setAdminPassword(e.target.value)}
                  placeholder="Enter passcode (Hint: 12345)"
                  className="block w-full px-3 py-2 border border-slate-300 rounded-lg text-sm bg-slate-50 focus:outline-none focus:ring-2 focus:ring-orange-400"
                  autoFocus
                />
              </div>

              {errorMsg && (
                <p className="text-xs text-red-600 bg-red-50 p-2 rounded font-medium border border-red-200">
                  ⚠️ {errorMsg}
                </p>
              )}

              <div className="pt-2 flex justify-end space-x-2">
                <button
                  type="button"
                  onClick={() => { setShowAdminLogin(false); setErrorMsg(''); }}
                   className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold rounded-lg transition cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-[#FF9933] hover:bg-[#E08528] text-slate-950 text-xs font-black uppercase rounded-lg transition cursor-pointer"
                >
                  Verify Access
                </button>
              </div>
            </form>
          </motion.div>
        </div>
      )}

      {/* Admin Post Create/Edit Form Overlay Modal */}
      {showAdminForm && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4 z-50 overflow-y-auto">
          <motion.div
            initial={{ scale: 0.98, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            className="bg-white rounded-2xl w-full max-w-2xl my-8 overflow-hidden shadow-2xl border border-slate-200 flex flex-col max-h-[90vh]"
          >
            {/* Header of Form */}
            <div className="bg-slate-900 px-6 py-4 text-white flex justify-between items-center flex-shrink-0">
              <div>
                <h3 className="text-sm font-bold uppercase tracking-wider flex items-center gap-1.5 font-sans">
                  <Sparkles className="h-4 w-4 text-amber-500" />
                  {formMode === 'create' ? 'Publish New Government Job Alert' : 'Edit Job Alert Specifications'}
                </h3>
                <p className="text-[10px] text-slate-404 mt-0.5 font-sans">Publish accurate, official recruitment vacancy details for youth candidates</p>
              </div>
              <button
                onClick={() => setShowAdminForm(false)}
                className="text-slate-400 hover:text-white cursor-pointer"
              >
                <X className="h-5 w-5" />
              </button>
            </div>

            {/* Main Form Fields scroll area */}
            <form onSubmit={handleFormSubmit} className="p-6 overflow-y-auto space-y-5 font-sans">
              
              {/* Load preset fast helpers */}
              <div className="bg-slate-50 border border-slate-200 p-3 rounded-xl">
                <p className="text-[11px] font-bold text-slate-500 uppercase tracking-widest mb-1.5 text-center">
                  💡 Select Quick Agency Presets:
                </p>
                <div className="grid grid-cols-3 gap-2">
                  <button
                    type="button"
                    onClick={() => applyAdminPreset('PSC')}
                    className="py-1 px-2.5 text-[10.5px] font-bold bg-amber-50 hover:bg-amber-100 text-amber-800 rounded border border-amber-205 transition cursor-pointer"
                  >
                    PSC (General Exam)
                  </button>
                  <button
                    type="button"
                    onClick={() => applyAdminPreset('Vyapam')}
                    className="py-1 px-2.5 text-[10.5px] font-bold bg-indigo-50 hover:bg-indigo-100 text-indigo-805 rounded border border-indigo-200 transition cursor-pointer"
                  >
                    Vyapam (Group C / D)
                  </button>
                  <button
                    type="button"
                    onClick={() => applyAdminPreset('Police')}
                    className="py-1 px-2.5 text-[10.5px] font-bold bg-red-50 hover:bg-red-100 text-red-800 rounded border border-red-200 transition cursor-pointer"
                  >
                    Police constable rules
                  </button>
                </div>
              </div>

              {/* Title Input */}
              <div>
                <label className="block text-[11px] font-extrabold text-slate-600 uppercase tracking-wider mb-1.5 font-sans">
                  Post / Recruitment Title *
                </label>
                <input
                  type="text"
                  required
                  value={formTitle}
                  onChange={(e) => setFormTitle(e.target.value)}
                  placeholder="e.g. CGPSC Civil Judge Class-II Written Examination Advt 2026"
                  className="block w-full px-3 py-2 border border-slate-300 rounded-lg text-sm bg-slate-5 font-semibold text-slate-800 focus:outline-none focus:ring-1 focus:ring-orange-400 font-sans"
                />
              </div>

              {/* Row 2: Department and Vacancies */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 font-sans">
                <div>
                  <label className="block text-[11px] font-extrabold text-slate-600 uppercase tracking-wider mb-1.5">
                    Department / Board Name *
                  </label>
                  <input
                    type="text"
                    required
                    value={formDept}
                    onChange={(e) => setFormDept(e.target.value)}
                    placeholder="e.g. CGPSC, CG Vyapam, Police, High Court"
                    className="block w-full px-3 py-2 border border-slate-300 rounded-lg text-sm bg-slate-5 focus:outline-none focus:ring-1 focus:ring-orange-400 font-sans"
                  />
                </div>

                <div>
                  <label className="block text-[11px] font-extrabold text-slate-600 uppercase tracking-wider mb-1.5">
                    Total Vacancies *
                  </label>
                  <input
                    type="number"
                    required
                    value={formVacancies}
                    onChange={(e) => setFormVacancies(Number(e.target.value))}
                    min={1}
                    className="block w-full px-3 py-2 border border-slate-300 rounded-lg text-sm bg-slate-5 font-mono focus:outline-none"
                  />
                </div>

                <div>
                  <label className="block text-[11px] font-extrabold text-slate-600 uppercase tracking-wider mb-1.5">
                    Location (Districts / Job Location)
                  </label>
                  <select
                    value={formDistricts}
                    onChange={(e) => setFormDistricts(e.target.value)}
                    className="block w-full px-3 py-2 border border-slate-300 rounded-lg text-xs bg-slate-5 focus:ring-1 text-slate-700 cursor-pointer"
                  >
                    {CHHATTISGARH_DISTRICTS.map((dist) => (
                      <option key={dist} value={dist}>{dist}</option>
                    ))}
                  </select>
                </div>
              </div>

              {/* Qualification Checklist selection */}
              <div>
                <label className="block text-[11px] font-extrabold text-slate-600 uppercase tracking-wider mb-1.5">
                  Required Educational Qualifications * (Select Multiple)
                </label>
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5 bg-slate-50 p-3 rounded-lg border border-slate-200">
                  {['8th/10th Pass', '12th Pass', 'Graduate', 'Post Graduate', 'ITI/Diploma', 'B.Ed/D.El.Ed', 'B.Sc Nursing'].map((qOpt) => {
                    const isChecked = formQuals.includes(qOpt);
                    return (
                      <label key={qOpt} className="flex items-center space-x-2 text-xs text-slate-705 font-medium cursor-pointer">
                        <input
                          type="checkbox"
                          checked={isChecked}
                          onChange={() => handleQualsCheck(qOpt)}
                          className="rounded border-slate-300 text-orange-550 focus:ring-orange-400 font-sans"
                        />
                        <span>{qOpt}</span>
                      </label>
                    );
                  })}
                </div>
              </div>

              {/* Short Descriptions */}
              <div>
                <label className="block text-[11px] font-extrabold text-slate-600 uppercase tracking-wider mb-1.5">
                  Brief Job Description *
                </label>
                <textarea
                  required
                  rows={2}
                  value={formShortDesc}
                  onChange={(e) => setFormShortDesc(e.target.value)}
                  placeholder="e.g. Applications are invited from eligible candidates who are domicile residents of Chhattisgarh..."
                  className="block w-full px-3 py-2 border border-slate-300 rounded-lg text-xs bg-slate-5 focus:outline-none"
                />
              </div>

              {/* Dates grid */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <div>
                  <label className="block text-[11px] font-extrabold text-slate-600 uppercase tracking-wider mb-1.5">
                    Start Date *
                  </label>
                  <input
                    type="date"
                    required
                    value={formStartDate}
                    onChange={(e) => setFormStartDate(e.target.value)}
                    className="block w-full px-3 py-2 border border-slate-300 rounded-lg text-xs bg-slate-5 font-mono cursor-pointer"
                  />
                </div>

                <div>
                  <label className="block text-[11px] font-extrabold text-slate-600 uppercase tracking-wider mb-1.5">
                    Submission Deadline *
                  </label>
                  <input
                    type="date"
                    required
                    value={formLastDate}
                    onChange={(e) => setFormLastDate(e.target.value)}
                    className="block w-full px-3 py-2 border border-slate-300 rounded-lg text-xs bg-slate-5 font-mono cursor-pointer"
                  />
                </div>

                <div>
                  <label className="block text-[11px] font-extrabold text-slate-600 uppercase tracking-wider mb-1.5">
                    Tentative Exam Date
                  </label>
                  <input
                    type="text"
                    value={formExamDate}
                    onChange={(e) => setFormExamDate(e.target.value)}
                    placeholder="e.g. 14 September 2026 or To Be Decided"
                    className="block w-full px-3 py-2 border border-slate-300 rounded-lg text-xs bg-slate-5 font-sans"
                  />
                </div>
              </div>

              {/* Fee Grid section */}
              <div className="border-t border-b border-dashed border-slate-200 py-3.5 space-y-3 font-sans">
                <p className="text-xs font-bold text-slate-700">Application Fee Details (Form Fees Structure):</p>
                <div className="grid grid-cols-1 sm:grid-cols-4 gap-3">
                  <div>
                    <label className="block text-[10px] text-slate-500 uppercase tracking-wider mb-0.5">Non-CG General</label>
                    <input
                      type="text"
                      value={formGeneralFee}
                      onChange={(e) => setFormGeneralFee(e.target.value)}
                      className="block w-full px-2 py-1.5 border border-slate-300 rounded text-xs"
                    />
                  </div>
                  <div>
                    <label className="block text-[10px] text-slate-500 uppercase tracking-wider mb-0.5">CG OBC</label>
                    <input
                      type="text"
                      value={formObcFee}
                      onChange={(e) => setFormObcFee(e.target.value)}
                      className="block w-full px-2 py-1.5 border border-slate-300 rounded text-xs"
                    />
                  </div>
                  <div>
                    <label className="block text-[10px] text-slate-500 uppercase tracking-wider mb-0.5">CG SC/ST</label>
                    <input
                      type="text"
                      value={formScStFee}
                      onChange={(e) => setFormScStFee(e.target.value)}
                      className="block w-full px-2 py-1.5 border border-slate-300 rounded text-xs"
                    />
                  </div>
                  <div>
                    <label className="block text-[10px] text-slate-500 uppercase tracking-wider mb-0.5">CG PWD</label>
                    <input
                      type="text"
                      value={formPwdFee}
                      onChange={(e) => setFormPwdFee(e.target.value)}
                      className="block w-full px-2 py-1.5 border border-slate-300 rounded text-xs"
                    />
                  </div>
                </div>
                <div>
                  <label className="block text-[10px] text-slate-500 uppercase tracking-wider mb-0.5">Fee Remarks / Notes:</label>
                  <input
                    type="text"
                    value={formFeeRemarks}
                    onChange={(e) => setFormFeeRemarks(e.target.value)}
                    placeholder="e.g. Domicile candidates of Chhattisgarh state are completely exempted from application exams fees."
                    className="block w-full px-2.5 py-1.5 border border-slate-300 rounded text-xs font-sans"
                  />
                </div>
              </div>

              {/* Links section */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 font-sans">
                <div>
                  <label className="block text-[11px] font-extrabold text-slate-600 uppercase tracking-wider mb-1.5">
                    Apply Online Registration URL *
                  </label>
                  <input
                    type="url"
                    required
                    value={formApplyUrl}
                    onChange={(e) => setFormApplyUrl(e.target.value)}
                    placeholder="https://vyapam.cgstate.gov.in"
                    className="block w-full px-3 py-2 border border-slate-300 rounded-lg text-xs bg-slate-5 font-mono focus:ring-1 focus:ring-orange-400"
                  />
                </div>

                <div>
                  <label className="block text-[11px] font-extrabold text-slate-600 uppercase tracking-wider mb-1.5">
                    Official Notification PDF URL *
                  </label>
                  <input
                    type="url"
                    value={formPdfUrl}
                    onChange={(e) => setFormPdfUrl(e.target.value)}
                    placeholder="https://vyapam.cgstate.gov.in/pdf/Recruitment.pdf"
                    className="block w-full px-3 py-2 border border-slate-300 rounded-lg text-xs bg-slate-5 font-mono"
                  />
                </div>
              </div>

              {/* Age limit criteria */}
              <div>
                <label className="block text-[11px] font-extrabold text-slate-600 uppercase tracking-wider mb-1.5">
                  Age Limit Criteria & Relaxations
                </label>
                <input
                  type="text"
                  value={formAgeLimit}
                  onChange={(e) => setFormAgeLimit(e.target.value)}
                  placeholder="e.g. 18 to 35 Years as of 01-01-2026. Reserved gets 5 year relaxation."
                  className="block w-full px-3 py-2 border border-slate-300 rounded-lg text-xs bg-slate-5"
                />
              </div>

              {/* Selection process details & structure */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 font-sans">
                <div>
                  <label className="block text-[11px] font-extrabold text-slate-600 uppercase tracking-wider mb-1.5">
                    Phases of Selection (Comma separated steps)
                  </label>
                  <input
                    type="text"
                    value={formSelection}
                    onChange={(e) => setFormSelection(e.target.value)}
                    placeholder="e.g. OMR Test, Interview, Medical Checkup"
                    className="block w-full px-3 py-2 border border-slate-300 rounded-lg text-xs bg-slate-5"
                  />
                </div>

                <div>
                  <label className="block text-[11px] font-extrabold text-slate-600 uppercase tracking-wider mb-1.5">
                    Exam Scheme & Syllabus Summary
                  </label>
                  <input
                    type="text"
                    value={formExamStructure}
                    onChange={(e) => setFormExamStructure(e.target.value)}
                    placeholder="e.g. Offline MCQ Written Exam of 150 Marks with 1/4 negative mark scheme."
                    className="block w-full px-3 py-2 border border-slate-300 rounded-lg text-xs bg-slate-5"
                  />
                </div>
              </div>

              {/* Syllabus input field */}
              <div>
                <label className="block text-[11px] font-extrabold text-slate-600 uppercase tracking-wider mb-1.5 font-sans">
                  Syllabus Subjects / Syllabus Outline - Enter one line per item
                </label>
                <textarea
                  rows={3}
                  value={formSyllabus}
                  onChange={(e) => setFormSyllabus(e.target.value)}
                  placeholder="E.g.&#10;Computer General Knowledge (50 Marks)&#10;General Hindi & Language Grammar (20 Marks)&#10;Mathematics (30 Marks)"
                  className="block w-full px-3 py-2 border border-slate-300 rounded-lg text-xs bg-slate-5 font-sans"
                />
              </div>

              {/* Featured toggle */}
              <div className="flex items-center space-x-2 font-sans">
                <input
                  type="checkbox"
                  id="formIsFeatured"
                  checked={formIsFeatured}
                  onChange={(e) => setFormIsFeatured(e.target.checked)}
                  className="rounded border-slate-300 text-orange-550 focus:ring-orange-400 cursor-pointer"
                />
                <label htmlFor="formIsFeatured" className="text-xs font-bold text-slate-700 cursor-pointer flex items-center gap-1">
                  <Sparkles className="h-4 w-4 text-orange-550" />
                  Mark this advertisement alert as a Featured Job (Highlight on Top)
                </label>
              </div>

              {/* Form Action Buttons */}
              <div className="pt-4 border-t border-slate-200 flex justify-end space-x-2 flex-shrink-0 font-sans">
                <button
                  type="button"
                  onClick={() => setShowAdminForm(false)}
                  className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold rounded-lg transition cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-black uppercase tracking-wider rounded-lg transition shadow-sm cursor-pointer"
                >
                  {formMode === 'create' ? 'Publish Alert' : 'Save Changes'}
                </button>
              </div>

            </form>
          </motion.div>
        </div>
      )}

      {/* Styled Portal Footer credits */}
      <footer className="bg-slate-900 text-slate-400 text-xs py-7 border-t border-slate-800 mt-10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center space-y-4 font-sans">
          <p className="font-medium text-slate-300">
            © 2026 Chhattisgarh Government Job Alerts (C.G. Govt Job Alerts). All Rights Reserved.
          </p>
          <div className="flex justify-center space-x-4 text-[11px] text-slate-500 font-semibold uppercase tracking-wide">
            <a href="https://psc.cg.gov.in" target="_blank" rel="noopener noreferrer" className="hover:text-slate-300 transition">CGPSC Portal</a>
            <span>•</span>
            <a href="https://vyapam.cgstate.gov.in" target="_blank" rel="noopener noreferrer" className="hover:text-slate-300 transition">CG Vyapam</a>
            <span>•</span>
            <a href="https://cgpolice.gov.in" target="_blank" rel="noopener noreferrer" className="hover:text-slate-300 transition">CG Police Dept</a>
            <span>•</span>
            <a href="https://highcourt.cg.gov.in" target="_blank" rel="noopener noreferrer" className="hover:text-slate-305 transition">HC Bilaspur</a>
          </div>
          <p className="text-[10px] text-slate-500 max-w-lg mx-auto leading-normal">
            <strong>Disclaimer:</strong> This is a highly optimized informational portal. Candidates are advised to read official advertisements published on the authorized websites of respective departments before applying online.
          </p>
        </div>
      </footer>
    </div>
  );
}
